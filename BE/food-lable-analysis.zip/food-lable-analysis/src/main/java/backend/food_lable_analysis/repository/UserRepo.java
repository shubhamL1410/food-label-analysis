package backend.food_lable_analysis.repository;


import java.util.Optional;
import org.springframework.data.mongodb.repository.MongoRepository;

import backend.food_lable_analysis.model.User;


public interface UserRepo extends MongoRepository<User, String> {

    Optional<User> findByUsername(String username);

}
